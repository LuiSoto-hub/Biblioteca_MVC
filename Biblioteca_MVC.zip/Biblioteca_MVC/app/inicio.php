<?php /*inicio.php Cargar clases en memoria de ejecucuón
*/ 
require_once("libs/defineConstantes.php");//define constantes de acceso
require_once("libs/MySQLdb.php");//carga en memoria gestor para base de datos
require_once("libs/Controlador.php");//fabrica de metodos y vistas 
require_once("libs/Control.php");//retorna y ejecuta un Recorset con elementos de la url por omision. 
?>