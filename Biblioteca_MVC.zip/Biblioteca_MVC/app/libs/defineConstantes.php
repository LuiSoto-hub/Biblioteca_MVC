<?php /*defineConstantes.php
//define constantes de acceso
*/
define("RUTA_APP","Biblioteca_MVC/");//constante de acceso
?>