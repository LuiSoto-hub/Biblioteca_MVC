# CapasRecordSet

- CapasRecordSet muestra la organización de una arquitectura por capas.
- Arquitectura ModeloVistaControlador.
- Renderiza en lista o tabla un RecordSet de datos de una tabla en base de datos.


![capasModeloVistaControlador](https://github.com/miRepositorioGit/CapasRecordSet/blob/main/public/img/tablaLibros.PNG "modelo en capascon Php")

![bdTabla](https://github.com/miRepositorioGit/CapasRecordSet/blob/main/public/img/bdTabla.PNG "base datos:libreria tabla:libros ")